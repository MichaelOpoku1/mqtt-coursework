import paho.mqtt.client as mqtt
import json
from datetime import datetime


broker = "localhost"
port = 1883
topic = "home/environment"
log_file = "environment_log.txt"


def on_message(client, userdata, msg):
    try:
        payload = json.loads(msg.payload.decode())
        temperature = payload["temperature"]
        humidity = payload["humidity"]

        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        with open(log_file, "a") as f:
            f.write(f"{timestamp} - Temp: {temperature} °C, Humidity: {humidity} %\n")

      
        print(f"{timestamp} | Temp: {temperature} °C | Humidity: {humidity} %")
    except Exception as e:
        print(f"Error: {e}")


client = mqtt.Client()
client.on_message = on_message
client.connect(broker, port)
client.subscribe(topic)

print("Subscriber started (terminal-only)... Press Ctrl+C to stop.")
client.loop_forever()
