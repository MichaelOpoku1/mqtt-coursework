MQTT Smart Home Monitoring

Simulates an IoT smart home using the MQTT protocol to monitor temperature and humidity.

Files Included
- `publisher.py`: Publishes inaccurate temperature/humidity readings using MQTT
- `subscriber_terminal.py`: Subscribes and logs to terminal (for Codio/headless usage)
- `plot_log.py`: Reads log file and plots line graph of the readings
- `requirements.txt`: Python dependencies

How to Run
1. Start Mosquitto broker: `mosquitto`
2. In the second terminal: `python3 publisher.py`
3. In the third terminal: `python3 subscriber_terminal.py`
4. For plotting data: `python3 plot_log.py`


Michael Opoku – 14498125 – Coventry University