import paho.mqtt.client as mqtt
import json
import random
import time


broker = "localhost"
port = 1883
topic = "home/environment"


client = mqtt.Client()
client.connect(broker, port)

print("Publisher started...")

while True:
 
    temperature = round(random.uniform(20.0, 30.0), 2)
    humidity = round(random.uniform(40.0, 60.0), 2)


    data = {
        "temperature": temperature,
        "humidity": humidity
    }


    client.publish(topic, json.dumps(data))
    print(f"Published: {data}")

    time.sleep(5)
