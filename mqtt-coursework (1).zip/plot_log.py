import matplotlib.pyplot as plt
from datetime import datetime

log_file = "environment_log.txt"

timestamps = []
temperatures = []
humidities = []

with open(log_file, "r") as file:
    for line in file:
        if not line.strip():
            continue 

        try:
            
            parts = line.strip().split(" - ")
            timestamp = datetime.strptime(parts[0], "%Y-%m-%d %H:%M:%S")
            temp = float(parts[1].split(":")[1].split("°")[0].strip())
            hum = float(parts[2].split(":")[1].split("%")[0].strip())

            timestamps.append(timestamp)
            temperatures.append(temp)
            humidities.append(hum)
        except Exception as e: # Comment this out if you don't want to see skipped line errors
            print(f" Skipped a line: {line.strip()}")

plt.figure(figsize=(10, 5))
plt.plot(timestamps, temperatures, label="Temperature (°C)", marker='o')
plt.plot(timestamps, humidities, label="Humidity (%)", marker='s')

plt.xlabel("Time")
plt.ylabel("Value")
plt.title("Temperature and Humidity Over Time")
plt.legend()
plt.grid(True)
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig("environment_plot.png")
print("Plot saved as environment_plot.png")
